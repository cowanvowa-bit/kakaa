package com.gwyf.casino;

/** Shared constants and math (used by both server and client). */
public final class Rules {
    private Rules() {}

    public static final int ACT_PLAY = 0;
    public static final int ACT_CASHOUT = 1;
    public static final int ACT_STEP = 2;
    public static final int ACT_CLOSE = 9;

    public static final int[] BETS = {5, 10, 25, 50, 100};

    public static boolean validBet(int bet) {
        for (int b : BETS) if (b == bet) return true;
        return false;
    }

    // Rocket (crash): multiplier grows exponentially with server ticks
    public static final double CRASH_RATE = 0.02;
    public static double crashMult(int ticks) {
        return Math.exp(CRASH_RATE * Math.max(0, ticks));
    }

    // Penguin cross
    public static final double PENGUIN_P = 0.75;
    public static final int PENGUIN_MAX = 10;
    public static double penguinMult(int steps) {
        if (steps <= 0) return 1.0;
        return Math.floor(0.95 / Math.pow(PENGUIN_P, steps) * 100.0) / 100.0;
    }

    // Slots: apple, gold, bell, emerald, diamond, nether star
    public static final int[] SLOT_WEIGHTS = {30, 25, 20, 14, 8, 3};
    public static final int[] SLOT_THREE = {5, 8, 15, 40, 100, 500};
    public static final double[] SLOT_PAIR = {0.5, 0.5, 1, 1, 1, 1};

    // Dice
    public static final double DICE_SIDE = 2.2;
    public static final double DICE_SEVEN = 5.5;
}
