package com.gwyf.casino;

public enum GameType {
    SLOTS(0, "slots"), CRASH(1, "crash"), DICE(2, "dice"), PENGUIN(3, "penguin");

    public final int id;
    public final String key;

    GameType(int id, String key) {
        this.id = id;
        this.key = key;
    }

    public static GameType byId(int id) {
        for (GameType g : values()) if (g.id == id) return g;
        return null;
    }
}
