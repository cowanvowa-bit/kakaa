package com.gwyf.casino;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GwyfCasino implements ModInitializer {
    public static final String MOD_ID = "gwyf";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();
        CasinoServer.init();

        ServerLifecycleEvents.SERVER_STARTED.register(GwyfCasino::buildAtSpawn);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("casino")
                        .then(CommandManager.literal("tp").executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            ServerWorld ow = p.getServer().getOverworld();
                            CasinoState st = CasinoState.get(ow);
                            if (!st.built) {
                                ctx.getSource().sendFeedback(() -> Text.translatable("gwyf.cmd.nocasino"), false);
                                return 0;
                            }
                            int x = st.x, z = st.z - 11;
                            int y = ow.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
                            p.teleport(ow, x + 0.5, y, z + 0.5, 0f, 0f);
                            return 1;
                        }))
                        .then(CommandManager.literal("build").requires(s -> s.hasPermissionLevel(2)).executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            BlockPos o = p.getBlockPos().down().offset(p.getHorizontalFacing(), 14);
                            ServerWorld world = p.getServerWorld();
                            CasinoStructure.build(world, o);
                            if (world.getRegistryKey() == World.OVERWORLD) CasinoState.get(world).set(o);
                            ctx.getSource().sendFeedback(() -> Text.translatable("gwyf.cmd.built", o.toShortString()), true);
                            return 1;
                        }))));
    }

    /** Builds the casino once, 14 blocks east of the world spawn. */
    private static void buildAtSpawn(MinecraftServer server) {
        ServerWorld ow = server.getOverworld();
        CasinoState st = CasinoState.get(ow);
        if (st.built) return;
        BlockPos sp = ow.getSpawnPos();
        int cx = sp.getX() + 14, cz = sp.getZ();
        int fy = ow.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, cx, cz) - 1;
        BlockPos origin = new BlockPos(cx, fy, cz);
        CasinoStructure.build(ow, origin);
        st.set(origin);
        LOGGER.info("Casino built at {}", origin.toShortString());
    }
}
