package com.gwyf.casino;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

public final class ModBlocks {
    private ModBlocks() {}

    public static final Block SLOT_MACHINE = register("slot_machine", new CasinoMachineBlock(settings(), GameType.SLOTS));
    public static final Block CRASH_MACHINE = register("crash_machine", new CasinoMachineBlock(settings(), GameType.CRASH));
    public static final Block DICE_MACHINE = register("dice_machine", new CasinoMachineBlock(settings(), GameType.DICE));
    public static final Block PENGUIN_MACHINE = register("penguin_machine", new CasinoMachineBlock(settings(), GameType.PENGUIN));

    private static FabricBlockSettings settings() {
        return FabricBlockSettings.of(Material.METAL)
                .strength(3.0f, 6.0f)
                .sounds(BlockSoundGroup.METAL)
                .luminance(state -> 6);
    }

    private static Block register(String id, Block block) {
        Identifier ident = new Identifier(GwyfCasino.MOD_ID, id);
        Registry.register(Registries.BLOCK, ident, block);
        Registry.register(Registries.ITEM, ident, new BlockItem(block, new FabricItemSettings()));
        return block;
    }

    public static void init() {}
}
