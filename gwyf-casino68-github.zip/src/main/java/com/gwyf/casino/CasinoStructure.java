package com.gwyf.casino;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/**
 * Builds the casino. Origin = center of the floor (the floor block itself, y = 0).
 * Size: 19 x 15, door on the north wall (z = -7), machines along the south wall.
 */
public final class CasinoStructure {
    private CasinoStructure() {}

    private static void put(ServerWorld w, BlockPos o, int x, int y, int z, BlockState s) {
        w.setBlockState(o.add(x, y, z), s, Block.NOTIFY_LISTENERS);
    }

    private static void put(ServerWorld w, BlockPos o, int x, int y, int z, Block b) {
        put(w, o, x, y, z, b.getDefaultState());
    }

    private static Block wall(int y, boolean pillar) {
        if (pillar) return Blocks.YELLOW_CONCRETE;
        if (y == 3 || y == 4) return Blocks.RED_STAINED_GLASS;
        return Blocks.POLISHED_BLACKSTONE_BRICKS;
    }

    public static void build(ServerWorld w, BlockPos o) {
        // clear the volume
        for (int x = -10; x <= 10; x++)
            for (int z = -8; z <= 8; z++)
                for (int y = 1; y <= 12; y++)
                    put(w, o, x, y, z, Blocks.AIR);

        // foundation, floor, roof
        for (int x = -9; x <= 9; x++) {
            for (int z = -7; z <= 7; z++) {
                for (int y = -5; y <= -1; y++) put(w, o, x, y, z, Blocks.STONE_BRICKS);
                put(w, o, x, 0, z, ((x + z) & 1) == 0 ? Blocks.BLACK_CONCRETE : Blocks.RED_CONCRETE);
                put(w, o, x, 7, z, (x % 3 == 0 && z % 3 == 0) ? Blocks.SEA_LANTERN : Blocks.POLISHED_BLACKSTONE);
            }
        }

        // walls
        for (int y = 1; y <= 6; y++) {
            for (int x = -9; x <= 9; x++) {
                boolean pillar = (x + 9) % 3 == 0;
                put(w, o, x, y, -7, wall(y, pillar));
                put(w, o, x, y, 7, wall(y, pillar));
            }
            for (int z = -6; z <= 6; z++) {
                boolean pillar = (z + 7) % 3 == 0;
                put(w, o, -9, y, z, wall(y, pillar));
                put(w, o, 9, y, z, wall(y, pillar));
            }
        }

        // door (3 wide, 3 high) on the north wall
        for (int x = -1; x <= 1; x++)
            for (int y = 1; y <= 3; y++)
                put(w, o, x, y, -7, Blocks.AIR);

        // red carpet from the door
        for (int z = -6; z <= 4; z++)
            for (int x = -1; x <= 1; x++)
                put(w, o, x, 1, z, Blocks.RED_CARPET);

        // the four machines against the south wall, fronts facing north (into the room)
        BlockState facing = null;
        int[] xs = {-6, -2, 2, 6};
        Block[] machines = {ModBlocks.SLOT_MACHINE, ModBlocks.CRASH_MACHINE, ModBlocks.DICE_MACHINE, ModBlocks.PENGUIN_MACHINE};
        for (int i = 0; i < 4; i++) {
            facing = machines[i].getDefaultState().with(HorizontalFacingBlock.FACING, Direction.NORTH);
            put(w, o, xs[i], 1, 6, facing);
        }

        // welcome chest with starter chips
        BlockPos chestPos = o.add(-8, 1, -5);
        w.setBlockState(chestPos, Blocks.CHEST.getDefaultState().with(ChestBlock.FACING, Direction.EAST), Block.NOTIFY_ALL);
        BlockEntity be = w.getBlockEntity(chestPos);
        if (be instanceof ChestBlockEntity chest) {
            chest.setStack(0, new ItemStack(ModItems.CHIP, 32));
            chest.setStack(1, new ItemStack(ModItems.CHIP, 32));
        }
    }
}
