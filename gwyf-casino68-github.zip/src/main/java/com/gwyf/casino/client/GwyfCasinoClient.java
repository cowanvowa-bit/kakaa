package com.gwyf.casino.client;

import com.gwyf.casino.CasinoServer;
import com.gwyf.casino.GameType;
import com.gwyf.casino.ResultPacket;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.screen.Screen;

public class GwyfCasinoClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(CasinoServer.OPEN, (client, handler, buf, responseSender) -> {
            int game = buf.readInt();
            int chips = buf.readInt();
            client.execute(() -> {
                GameType g = GameType.byId(game);
                if (g != null) client.setScreen(create(g, chips));
            });
        });
        ClientPlayNetworking.registerGlobalReceiver(CasinoServer.RESULT, (client, handler, buf, responseSender) -> {
            ResultPacket r = ResultPacket.read(buf);
            client.execute(() -> {
                if (client.currentScreen instanceof CasinoScreen cs) cs.receive(r);
            });
        });
    }

    private static Screen create(GameType g, int chips) {
        return switch (g) {
            case SLOTS -> new SlotsScreen(chips);
            case CRASH -> new CrashScreen(chips);
            case DICE -> new DiceScreen(chips);
            case PENGUIN -> new PenguinScreen(chips);
        };
    }
}
