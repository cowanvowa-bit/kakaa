package com.gwyf.casino.client;

import com.gwyf.casino.CasinoServer;
import com.gwyf.casino.Ev;
import com.gwyf.casino.GameType;
import com.gwyf.casino.ModItems;
import com.gwyf.casino.ResultPacket;
import com.gwyf.casino.Rules;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;

/** Common frame for all machines: panel, chip counter, bet selector, networking. */
public abstract class CasinoScreen extends Screen {
    protected final GameType game;
    protected int chips;
    protected int betIdx = 1;
    protected String message = "";
    protected int messageColor = 0xFFFFFFFF;
    protected boolean busy = false;
    protected final int panelW = 320, panelH = 210;
    protected int left, top;

    protected CasinoScreen(GameType game, int chips) {
        super(Text.translatable("gwyf.game." + game.key));
        this.game = game;
        this.chips = chips;
    }

    protected int bet() { return Rules.BETS[betIdx]; }

    @Override
    protected void init() {
        left = (width - panelW) / 2;
        top = (height - panelH) / 2;
        int by = top + panelH - 26;
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> {
            if (!busy && betIdx > 0) betIdx--;
        }).dimensions(left + 10, by, 20, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
            if (!busy && betIdx < Rules.BETS.length - 1) betIdx++;
        }).dimensions(left + 90, by, 20, 20).build());
        initGame(left, top);
    }

    protected abstract void initGame(int left, int top);
    protected abstract void drawGame(DrawContext ctx, int mx, int my, float delta);
    protected abstract void handle(ResultPacket r);
    protected void tickGame() {}
    protected void onNoChips() {}
    protected abstract String hintKey();

    public final void receive(ResultPacket r) {
        if (r.event() == Ev.NO_CHIPS) {
            chips = r.chips();
            busy = false;
            onNoChips();
            setMessage(Text.translatable("gwyf.ui.nochips").getString(), 0xFFFF5555);
            return;
        }
        handle(r);
    }

    @Override
    public void tick() {
        tickGame();
    }

    protected void setMessage(String msg, int color) {
        message = msg;
        messageColor = color;
    }

    protected void sendAction(int action, int arg, int arg2) {
        if (client == null || client.getNetworkHandler() == null) return;
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(game.id);
        buf.writeInt(action);
        buf.writeInt(arg);
        buf.writeInt(arg2);
        ClientPlayNetworking.send(CasinoServer.ACTION, buf);
    }

    protected void play(SoundEvent e, float pitch) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(e, pitch, 0.6f));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx);
        ctx.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, 0xFFD4AF37);
        ctx.fill(left, top, left + panelW, top + panelH, 0xFF1B1B24);
        ctx.drawCenteredTextWithShadow(textRenderer, title, left + 60, top + 8, 0xFFD4AF37);
        ctx.drawItem(new ItemStack(ModItems.CHIP), left + panelW - 78, top + 4);
        ctx.drawTextWithShadow(textRenderer, Text.translatable("gwyf.ui.chips", chips), left + panelW - 58, top + 8, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable("gwyf.ui.bet", bet()), left + 60, top + panelH - 40, 0xFFFFFFFF);
        drawGame(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable(hintKey()), left + panelW / 2, top + 130, 0xFF9A9AAA);
        if (!message.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, message, left + panelW / 2, top + 142, messageColor);
        }
        super.render(ctx, mx, my, delta);
    }

    @Override
    public boolean shouldPause() {
        return false; // the server must keep ticking (rocket timer!)
    }

    @Override
    public void removed() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() != null && ClientPlayNetworking.canSend(CasinoServer.ACTION)) {
            sendAction(Rules.ACT_CLOSE, 0, 0);
        }
        super.removed();
    }
}
