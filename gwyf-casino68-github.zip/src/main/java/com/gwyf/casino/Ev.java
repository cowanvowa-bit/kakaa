package com.gwyf.casino;

/** Event ids for server -> client result packets. */
public final class Ev {
    private Ev() {}
    public static final int NO_CHIPS = 0;
    public static final int SLOTS_RESULT = 1;
    public static final int CRASH_STARTED = 2;
    public static final int CRASH_CASHED = 3;
    public static final int CRASH_CRASHED = 4;
    public static final int DICE_RESULT = 5;
    public static final int PENGUIN_STARTED = 6;
    public static final int PENGUIN_STEP = 7;
    public static final int PENGUIN_FELL = 8;
    public static final int PENGUIN_CASHED = 9;
}
