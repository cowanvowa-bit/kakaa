package com.gwyf.casino;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;

/** Remembers whether the spawn casino was built and where. */
public class CasinoState extends PersistentState {
    public boolean built = false;
    public int x, y, z;

    public static CasinoState fromNbt(NbtCompound nbt) {
        CasinoState s = new CasinoState();
        s.built = nbt.getBoolean("built");
        s.x = nbt.getInt("x");
        s.y = nbt.getInt("y");
        s.z = nbt.getInt("z");
        return s;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        nbt.putBoolean("built", built);
        nbt.putInt("x", x);
        nbt.putInt("y", y);
        nbt.putInt("z", z);
        return nbt;
    }

    public void set(BlockPos pos) {
        built = true;
        x = pos.getX();
        y = pos.getY();
        z = pos.getZ();
        markDirty();
    }

    public static CasinoState get(ServerWorld world) {
        return world.getPersistentStateManager().getOrCreate(CasinoState::fromNbt, CasinoState::new, "gwyf_casino");
    }
}
