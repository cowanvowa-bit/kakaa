package com.example.rubymod;

import net.minecraft.item.Item;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.item.SwordItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
	public static final Item RUBY = register("ruby", new Item(new Item.Settings()));

	public static final Item RUBY_SWORD = register("ruby_sword",
			new SwordItem(RubyToolMaterial.INSTANCE, 3, -2.4f, new Item.Settings()));

	public static final Item RUBY_BOAR_SPAWN_EGG = register("ruby_boar_spawn_egg",
			new SpawnEggItem(ModEntities.RUBY_BOAR, 0xC8102E, 0xFFB3C1, new Item.Settings()));

	private static Item register(String name, Item item) {
		return Registry.register(Registries.ITEM, new Identifier(RubyMod.MOD_ID, name), item);
	}

	public static void register() {
		// Calling this loads the class, which registers the items above.
	}
}
