package com.example.rubymod.client;

import com.example.rubymod.RubyMod;
import com.example.rubymod.entity.RubyBoarEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PigEntityModel;
import net.minecraft.util.Identifier;

public class RubyBoarRenderer extends MobEntityRenderer<RubyBoarEntity, PigEntityModel<RubyBoarEntity>> {
	private static final Identifier TEXTURE = new Identifier(RubyMod.MOD_ID, "textures/entity/ruby_boar.png");

	public RubyBoarRenderer(EntityRendererFactory.Context context) {
		super(context, new PigEntityModel<>(context.getPart(EntityModelLayers.PIG)), 0.7f);
	}

	@Override
	public Identifier getTexture(RubyBoarEntity entity) {
		return TEXTURE;
	}
}
