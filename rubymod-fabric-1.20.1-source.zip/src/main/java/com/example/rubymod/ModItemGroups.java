package com.example.rubymod;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItemGroups {
	public static final ItemGroup RUBY_GROUP = Registry.register(
			Registries.ITEM_GROUP,
			new Identifier(RubyMod.MOD_ID, "ruby_group"),
			FabricItemGroup.builder()
					.icon(() -> new ItemStack(ModItems.RUBY))
					.displayName(Text.translatable("itemGroup.rubymod.ruby_group"))
					.entries((displayContext, entries) -> {
						entries.add(ModItems.RUBY);
						entries.add(ModBlocks.RUBY_BLOCK);
						entries.add(ModItems.RUBY_SWORD);
						entries.add(ModItems.RUBY_BOAR_SPAWN_EGG);
					})
					.build());

	public static void register() {
		// Calling this loads the class, which registers the creative tab.
	}
}
