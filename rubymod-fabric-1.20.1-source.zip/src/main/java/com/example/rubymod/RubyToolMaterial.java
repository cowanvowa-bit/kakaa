package com.example.rubymod;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class RubyToolMaterial implements ToolMaterial {
	public static final RubyToolMaterial INSTANCE = new RubyToolMaterial();

	@Override
	public int getDurability() {
		return 1800;
	}

	@Override
	public float getMiningSpeedMultiplier() {
		return 8.0f;
	}

	@Override
	public float getAttackDamage() {
		return 3.5f;
	}

	@Override
	public int getMiningLevel() {
		return 3;
	}

	@Override
	public int getEnchantability() {
		return 18;
	}

	@Override
	public Ingredient getRepairIngredient() {
		return Ingredient.ofItems(ModItems.RUBY);
	}
}
