package com.example.rubymod;

import com.example.rubymod.entity.RubyBoarEntity;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.BiomeKeys;

public class ModEntities {
	public static final EntityType<RubyBoarEntity> RUBY_BOAR = Registry.register(
			Registries.ENTITY_TYPE,
			new Identifier(RubyMod.MOD_ID, "ruby_boar"),
			FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, RubyBoarEntity::new)
					.dimensions(EntityDimensions.fixed(0.9f, 0.9f))
					.build());

	public static void register() {
		FabricDefaultAttributeRegistry.register(RUBY_BOAR, RubyBoarEntity.createRubyBoarAttributes());

		BiomeModifications.addSpawn(
				BiomeSelectors.includeByKey(BiomeKeys.PLAINS, BiomeKeys.FOREST, BiomeKeys.MEADOW, BiomeKeys.SAVANNA),
				SpawnGroup.CREATURE, RUBY_BOAR, 10, 1, 3);
	}
}
