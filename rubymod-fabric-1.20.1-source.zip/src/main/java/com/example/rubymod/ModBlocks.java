package com.example.rubymod;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModBlocks {
	public static final Block RUBY_BLOCK = register("ruby_block",
			new Block(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK)));

	private static Block register(String name, Block block) {
		Identifier id = new Identifier(RubyMod.MOD_ID, name);
		Block registered = Registry.register(Registries.BLOCK, id, block);
		Registry.register(Registries.ITEM, id, new BlockItem(registered, new Item.Settings()));
		return registered;
	}

	public static void register() {
		// Calling this loads the class, which registers the blocks above.
	}
}
