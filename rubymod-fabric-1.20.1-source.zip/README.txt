Ruby Mod - Fabric, Minecraft 1.20.1 (Java 17)

Добавляет: Рубин, Рубиновый блок, Рубиновый меч, Рубинового кабана (+ яйцо призыва).
Всё лежит во вкладке творческого режима "Рубиновый мод". Моб: /summon rubymod:ruby_boar

КАК ПОЛУЧИТЬ .JAR БЕЗ УСТАНОВКИ ПРОГРАММ (через GitHub):
1. Зарегистрируйтесь на github.com, создайте новый репозиторий (New repository).
2. Нажмите "uploading an existing file" и перетащите ВСЕ файлы и папки из этого архива
   (включая папку .github). Нажмите Commit changes.
3. Откройте вкладку Actions -> build -> дождитесь зелёной галочки (2-5 минут).
4. Внутри запуска внизу скачайте "rubymod-jar", распакуйте - внутри rubymod-1.0.0.jar.

ЧТО НУЖНО ДЛЯ ИГРЫ: Minecraft 1.20.1, Fabric Loader 0.14.21+, Fabric API для 1.20.1.
Положите rubymod-1.0.0.jar и Fabric API в папку mods.

ЛОКАЛЬНАЯ СБОРКА: JDK 17 + IntelliJ IDEA, откройте папку, задача Gradle "build",
готовый файл появится в build/libs/.
